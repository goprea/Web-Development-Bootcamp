const contacts = [
  {
    name: "Beyonce",
    imgURL:
      "https://static01.nyt.com/images/2022/06/17/multimedia/16beyonce1/16beyonce1-articleLarge.jpg?quality=75&auto=webp&disable=upscale",
    phone: "+123 456 789",
    email: "b@beyonce.com"
  },
  {
    name: "Jack Bauer",
    imgURL:
      "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS0kwodDrXOMWfqyhTRkGHycCWPZmItCqB0KA&usqp=CAU",
    phone: "+987 654 321",
    email: "jack@nowhere.com"
  },
  {
    name: "Chuck Norris",
    imgURL: "https://i.iplsc.com/-/000ER178R6KD6Q6L-C122.jpg",
    phone: "+918 372 574",
    email: "gmail@chucknorris.com"
  }
];

export default contacts;
